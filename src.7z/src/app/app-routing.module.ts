import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ParentlistdisplayComponent } from './components/parentlistdisplay/parentlistdisplay.component';


const routes: Routes = [
  {path:'',component:ParentlistdisplayComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
