import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildpopupviewComponent } from './childpopupview.component';

describe('ChildpopupviewComponent', () => {
  let component: ChildpopupviewComponent;
  let fixture: ComponentFixture<ChildpopupviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildpopupviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildpopupviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
