import { Component, OnInit, ViewChild, Output, EventEmitter, ElementRef, Inject, Input } from '@angular/core';
import { AddressVM, InfoVM } from './dataclass';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ParentlistdisplayComponent } from '../parentlistdisplay/parentlistdisplay.component';

declare let $: any;

@Component({
  selector: 'app-childpopupview',
  templateUrl: './childpopupview.component.html',
  styleUrls: ['./childpopupview.component.css']
})
export class ChildpopupviewComponent implements OnInit {
  @Output() sendData: EventEmitter<any> = new EventEmitter();
  @Input() parentListRecord: any;
  @Input() valueCheck:any;
  @Input('parent') parent;
  @Output() updateNewData: EventEmitter<any> = new EventEmitter();

  @ViewChild('myForm', { static: false }) form;

  infoVM: InfoVM;
  address: AddressVM;
  infoVMList: InfoVM[] = [];
  tempInfoVMList: any;
  addressList: AddressVM[] = [];
  countryvalue: any;
  data: any;
  indexvalue: number;
  updateButton: boolean = false;
  addButton: boolean = true;
  formClose: boolean = false;
  editDatavalue: any;
  p:any;


  countries: Array<any> = [
    {
      name: 'Germany', states: [{ name: 'GermState', cities: ['paris', 'Eibiza', 'Escborn', 'Hazlewina'] },
      { name: 'Germstate2', cities: ['Emou', 'Aukland', 'Hickieny', 'Istania'] }]
    },
    { name: 'Spain', states: [{ name: 'SpanState', cities: ['Madrid', 'Barcelona', 'Palma', 'Valencia'] }] },
    { name: 'India', states: [{ name: 'IndiaState', cities: ['Delhi', 'Ahmedabad', 'Chandigarh', 'Jaipur', 'banglore'] }] },
    { name: 'USA', states: [{ name: 'USAState', cities: ['NewYork', 'LasVegas', 'Columbia', 'tampa'] }] },
    { name: 'Australia', states: [{ name: 'AustrailiaState', cities: ['Melbourne', 'Sydney', 'Okao', 'Arizona'] }] }
  ];

  constructor() {
    // this.infoVMList = this.parentListRecord;
  }

  ngOnInit() {

    this.infoVM = new InfoVM();
    this.address = new AddressVM();
    this.infoVM.AddressList = [];
    this.address.CountryList = this.countries;
    this.infoVM.AddressList.push(this.address);

    // this.infoVMList = this.parentListRecord;
    // this.tempInfoVMList = this.infoVMList;
    // console.log("infovm list obtain iss=====", this.infoVMList);

  }


  changeCountry = (country, index) => {
    this.countryvalue = country;
    this.infoVM.AddressList[index].StateList = this.countries.find(cntry => cntry.name == country).states;
  }

  changeState = (statevalue, index) => {
    this.infoVM.AddressList[index].CityList = this.countries.find(cntry => cntry.name == this.countryvalue).states.find(stat => stat.name == statevalue).cities;
  }

  addAddress() {
    this.address = new AddressVM();
    this.address.CountryList = this.countries;
    this.infoVM.AddressList.push(this.address);
  }

  removeAddress(i: any) {
    this.infoVM.AddressList.splice(i, 1);
  }

  closeForm() {
    $('myForm').modal('hide');
  }


  submitForm() {
    debugger
    let a = 0;
    this.data = this.infoVM;
    this.sendData.emit(this.data);
    //  debugger
    // this.tempInfoVMList = this.parentListRecord;
    // for(a;a<this.tempInfoVMList.length;a++)
    // {
    //   if(this.tempInfoVMList[a].Email == this.data.Email){
    //     alert("Email Already Exisit");
    //     return;

    //   }
    // }
    alert("consition rcvd iss---"+ this.valueCheck);
    // console.log("type of p --",typeof(this.p));

    if (this.valueCheck) {
      $('#myModal').modal('hide');

      this.infoVM = new InfoVM();
      this.address = new AddressVM();
      this.infoVM.AddressList = [];
      this.infoVM.AddressList.push(this.address);
    }


  }

  openPopup() {
    this.address.CountryList = this.countries;
    this.form.reset();
    $('#myModal').modal('show');

  }

  editData(data, indexval) {
    debugger
    this.editDatavalue = data;
    // console.log("edit data value ---", this.editDatavalue)
    this.updateButton = true;
    this.addButton = false;
    this.indexvalue = indexval;

    $('#myModal').modal('show');
    // this.infoVM = this.tempInfoVMList[indexval];
    this.infoVM = this.editDatavalue;
    // this.tempInfoVMList = this.infoVMList

  }

  updateForm() {
    debugger;
    let updatedData;
    updatedData = this.infoVM;
    this.updateButton = true;
    this.addButton = false;
    this.tempInfoVMList = this.parentListRecord;
    for (let a = 0; a < this.tempInfoVMList.length; a++) {
      if (this.tempInfoVMList[a].Email == updatedData.Email) {
        alert("Email Already Exisit");
        return;

      }
    }

    alert("updated successfully");
    $('#myModal').modal('hide')
    this.tempInfoVMList[this.indexvalue] = updatedData;
    this.updateNewData.emit(this.tempInfoVMList);
    this.infoVM = new InfoVM();
    this.address = new AddressVM();
    this.infoVM.AddressList = [];
    this.infoVM.AddressList.push(this.address);

  }

  closePopup() {

    this.updateButton = false;
    this.addButton = true;
    $('#myModal').modal('hide');
    this.infoVM = new InfoVM();
    this.address = new AddressVM();
    this.infoVM.AddressList = [];
    this.infoVM.AddressList.push(this.address);

  }

}
