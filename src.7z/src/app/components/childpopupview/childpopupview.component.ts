import { Component, OnInit, ViewChild, Output, EventEmitter, ElementRef, Inject, Input } from '@angular/core';
import { AddressVM, InfoVM } from './dataclass';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ParentlistdisplayComponent } from '../parentlistdisplay/parentlistdisplay.component';

declare let $: any;

@Component({
  selector: 'app-childpopupview',
  templateUrl: './childpopupview.component.html',
  styleUrls: ['./childpopupview.component.css']
})
export class ChildpopupviewComponent implements OnInit {
  @Output() sendData:EventEmitter<any> = new EventEmitter();
  @Input() parentListRecord: any;
  
  @ViewChild('myForm', { static: false }) form;
 
  infoVM: InfoVM;
  address: AddressVM;
  infoVMList: InfoVM[] = [];
  tempInfoVMList:InfoVM[] = [];
  addressList: AddressVM[] = [];
  countryvalue: any;
  data: any;
  indexvalue:number;
  updateButton:boolean = false;
  addButton:boolean = true;
  // loadComponent:boolean = false;
 formClose: boolean = false;

 countries: Array<any> = [
    {
      name: 'Germany', states: [{ name: 'GermState', cities: ['paris', 'Eibiza', 'Escborn', 'Hazlewina'] },
      { name: 'Germstate2', cities: ['Emou', 'Aukland', 'Hickieny', 'Istania'] }]
    },
    { name: 'Spain', states: [{ name: 'SpanState', cities: ['Jimiliya', 'Chreshoch', 'Hathwaw'] }] },
    { name: 'India', states: [{ name: 'IndiaState', cities: ['Delhi', 'Ahmedabad', 'Chandigarh', 'Jaipur', 'banglore'] }] },
    { name: 'USA', states: [{ name: 'USAState', cities: ['NewYork', 'LasVegas', 'Columbia', 'tampa'] }] },
    { name: 'Australia', states: [{ name: 'AustrailiaState', cities: ['Melbourne', 'Sydney', 'Okao', 'Arizona'] }] }
  ];
  constructor() {

  }

  ngOnInit() {
  
    this.infoVM = new InfoVM();
    this.address = new AddressVM();
    this.infoVM.AddressList = [];
    this.address.CountryList = this.countries;
    this.infoVM.AddressList.push(this.address);
    this.infoVMList = this.parentListRecord;
    console.log("infovm list obtain iss=====", this.infoVMList);
    
  }


  changeCountry = (country, index) => {
    //debugger
    console.log("COUNTRY SELECTED ISS--", country);
    this.countryvalue = country;
    this.infoVM.AddressList[index].StateList = this.countries.find(cntry => cntry.name == country).states;
    console.log("STATEVALUE LIST==", this.infoVM.AddressList[index].StateList);

  }

  changeState = (statevalue, index) => {
    // debugger
    console.log("State selected is--", statevalue);
    this.infoVM.AddressList[index].CityList = this.countries.find(cntry => cntry.name == this.countryvalue).states.find(stat => stat.name == statevalue).cities;
    console.log("CITYVALUE LIST==", this.infoVM.AddressList[index].CityList);
  }
  
  addAddress() {
    // debugger
    this.address = new AddressVM();
    // this.infoVMChild.AddressList = [];
    this.address.CountryList = this.countries;
    this.infoVM.AddressList.push(this.address);

  }

  removeAddress(i: any) {
    console.log("address list is --", this.infoVM.AddressList);
    this.infoVM.AddressList.splice(i, 1);
  }

  closeForm() {
    $('myForm').modal('hide');
  }

  // checkEmail(event){
  //   console.log("aaaa---", event);
  //   console.log("on chnage", this.infoVMList);
    
    
  // }
  submitForm() {
    debugger
        let a = 0;

        for(a;a<this.infoVMList.length;a++)
        {
          if(this.infoVMList[a].Email == this.infoVM.Email ){
            alert("Email Already Exisit");
            return;
            
          }
        }
      
        this.data = this.infoVM;
        this.sendData.emit(this.data);
          this.infoVM = new InfoVM();
          this.address = new AddressVM();
          this.infoVM.AddressList = [];
          this.infoVM.AddressList.push(this.address);
          $('#myModal').modal('hide');
  
              
 
   
    
  }

  openPopup(){
     debugger
    this.infoVM = new InfoVM();
    this.address = new AddressVM();
    this.infoVM.AddressList = [];
    this.address.CountryList = this.countries;
    this.infoVM.AddressList.push(this.address);
    $('#myModal').modal('show');
    this.form.reset();
  }

  editData(data,indexval){
    debugger
    this.updateButton = true;
    this.addButton = false;
    this.indexvalue =indexval;
   
    //   this.infoVM = new InfoVM();
    //   this.address = new AddressVM();
    // this.infoVM.AddressList = [];
    // this.address.CountryList = this.countries;
    // this.infoVM.AddressList.push(this.address);
    this.infoVM = data;
    console.log("infoVM DATA @@@@", this.infoVM);
    
    $('#myModal').modal('show');
    
  }

  updateForm(){
    debugger;
    alert("updated successfully");
    console.log("index value rcvd in update form --------", this.indexvalue);
    let updatedData;
    updatedData = this.infoVM;
    console.log("new updated value iss*******", this.infoVMList);
    this.updateButton = false;
    this.addButton = true;
    $('#myModal').modal('hide')
    this.tempInfoVMList = this.infoVMList;
    console.log("tempInfoVMList",this.tempInfoVMList);
    
    this.tempInfoVMList[this.indexvalue] = updatedData;
    
    // for(let i ;i<=this.infoVMList.length;i++)
    // {
    //   if(i == this.)
    // }
    
   
    
  }
  closePopup(){
    debugger

    $('#myModal').modal('hide');
    
    console.log("infovm value--",this.infoVM);
  }

}
