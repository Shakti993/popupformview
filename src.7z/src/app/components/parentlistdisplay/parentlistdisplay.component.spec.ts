import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParentlistdisplayComponent } from './parentlistdisplay.component';

describe('ParentlistdisplayComponent', () => {
  let component: ParentlistdisplayComponent;
  let fixture: ComponentFixture<ParentlistdisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParentlistdisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParentlistdisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
