import { Component, OnInit } from '@angular/core';
import { InfoVM } from '../childpopupview/dataclass';



@Component({
  selector: 'app-parentlistdisplay',
  templateUrl: './parentlistdisplay.component.html',
  styleUrls: ['./parentlistdisplay.component.css']
})
export class ParentlistdisplayComponent implements OnInit {

  infoVM: InfoVM = new InfoVM();
  infoVMList: InfoVM[] = [];
  fname: any;
  lname: any;
  email: any;
  mobile: any;
  city: any;
  constructor() { }


  ngOnInit() {
   
  }
  receiveData(event: any) {
    debugger
    this.infoVMList.push(event);
  }
  deleteRecord(newindex){
    this.infoVMList.splice(newindex,1);
  }
  
}
