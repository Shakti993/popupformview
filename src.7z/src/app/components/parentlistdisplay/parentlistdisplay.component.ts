import { Component, OnInit, ViewChild } from '@angular/core';
import { InfoVM } from '../childpopupview/dataclass';
import { ChildpopupviewComponent } from '../childpopupview/childpopupview.component';



@Component({
  selector: 'app-parentlistdisplay',
  templateUrl: './parentlistdisplay.component.html',
  styleUrls: ['./parentlistdisplay.component.css']
})
export class ParentlistdisplayComponent implements OnInit {
  @ViewChild(ChildpopupviewComponent,{static:false}) child;
  infoVM: InfoVM = new InfoVM();
  infoVMList: InfoVM[] = [];
  data:any;
  isNotValid:boolean = true;
  constructor() { }


  ngOnInit() {
   
  }
  receiveData(event: any) {
  //  debugger
    this.data = event;
    for(let a=0;a<this.infoVMList.length;a++){
      
      if(this.infoVMList[a].Email == this.data.Email){
        alert("Email Already Exisit");
        this.isNotValid = false;
        return ;
        
      }
    }
    // this.infoVMList.forEach(element => {
    //   if(element.Email==this.data.Email)
    //   {
    //     alert("Email Already Exisit");
    //     return ;
    //   }
    // });
    // this.isNotValid = true;
    this.infoVMList.push(this.data);
    }

    updateData(event: any) {
      debugger
      let newdata = event;
      console.log("data rcvd iss----",newdata);
      this.infoVMList = newdata;
      }
     
   
  deleteRecord(newindex){
    debugger
    let confirmBox = confirm("Are Sure Want to delete?");
    if(confirmBox == true)
    {
      this.infoVMList.splice(newindex,1);
    }
    else {
      return;
    }
    // if(confirm){
    //   this.infoVMList.splice(newindex,1);
    // }
  }
 
}
